import json
import os
import sys

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import Base  # noqa: E402
from app.models import Competency, Question  # noqa: E402
from app.schemas import AnswerSubmission  # noqa: E402
from app.services.diagnostic_engine import diagnostic_engine  # noqa: E402


@pytest.fixture()
def db():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    session = sessionmaker(bind=engine)()
    session.add(
        Competency(
            competency_id="C1",
            competency_name="Sampling Design",
            description="Designing and executing survey samples.",
            domain="Functional",
        )
    )
    for idx, correct in enumerate(["A", "B"], start=1):
        session.add(
            Question(
                question_id=f"Q{idx}",
                quiz_id="QZ1",
                competency_mapped="C1",
                scenario_text=f"Scenario {idx}",
                options_json=json.dumps({"A": "a", "B": "b", "C": "c", "D": "d"}),
                correct_option=correct,
                explanation="because",
                distractor_analysis_json=json.dumps({"C": "Confuses frame with sample"}),
            )
        )
    session.commit()
    yield session
    session.close()


def test_all_correct_yields_full_score_and_no_gaps(db):
    answers = [
        AnswerSubmission(question_id="Q1", selected_option="a", confidence="high"),
        AnswerSubmission(question_id="Q2", selected_option="B", confidence="low"),
    ]
    score, total, pct, message, comps, gaps, reviews = diagnostic_engine.evaluate_quiz(db, "QZ1", answers)

    assert (score, total, pct) == (2, 2, 100.0)
    assert "Outstanding" in message
    assert comps[0].status == "Strong"
    assert gaps == []
    assert len(reviews) == 2


def test_high_confidence_error_is_flagged_as_critical_gap(db):
    answers = [
        AnswerSubmission(question_id="Q1", selected_option="C", confidence="high"),
        AnswerSubmission(question_id="Q2", selected_option="B", confidence="low"),
    ]
    score, total, pct, _, comps, gaps, _ = diagnostic_engine.evaluate_quiz(db, "QZ1", answers)

    assert (score, total, pct) == (1, 2, 50.0)
    assert comps[0].status == "Needs Attention"
    assert len(gaps) == 1
    assert gaps[0].severity == "Critical"
    assert gaps[0].confidence_factor == "High Misconception"
    assert "frame" in gaps[0].diagnostic_summary


def test_unknown_question_ids_are_ignored_and_empty_quiz_is_safe(db):
    answers = [AnswerSubmission(question_id="MISSING", selected_option="A", confidence="low")]
    score, total, pct, _, comps, gaps, reviews = diagnostic_engine.evaluate_quiz(db, "QZ1", answers)

    assert score == 0
    assert total == 1
    assert pct == 0.0
    assert comps == [] and gaps == [] and reviews == []

    score, total, pct, _, _, _, _ = diagnostic_engine.evaluate_quiz(db, "QZ1", [])
    assert (score, total, pct) == (0, 0, 0.0)
