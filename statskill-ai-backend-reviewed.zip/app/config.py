from typing import List

from pydantic_settings import BaseSettings

DEV_SECRET_KEY = "statskill-hackathon-2026-secret-key"


class Settings(BaseSettings):
    APP_NAME: str = "StatSkill AI"
    ENV: str = "development"
    SECRET_KEY: str = DEV_SECRET_KEY
    DATABASE_URL: str = "sqlite:///./statskill.db"

    # AI Engine Configuration
    AI_PROVIDER: str = "mock"  # "mock", "gemini", "openai", "anthropic"
    AI_API_KEY: str = ""
    AI_MODEL_NAME: str = "gemini-2.5-flash"
    AI_BASE_URL: str = ""
    AI_MAX_TOKENS: int = 2048
    AI_TEMPERATURE: float = 0.2

    # Security / networking
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:5173,http://localhost:8000"
    ALLOW_CREDENTIALS: bool = True

    # Feature Flags & Limits
    ENABLE_OCR: bool = True
    ENABLE_HUMAN_REVIEW_MODE: bool = True
    MAX_UPLOAD_FILE_SIZE_MB: int = 15
    ALLOWED_FILE_EXTENSIONS: str = ".pdf,.txt,.md,.png,.jpg,.jpeg"
    ALLOWED_FILE_TYPES: str = "application/pdf,text/plain,application/vnd.ms-powerpoint"
    LOG_LEVEL: str = "INFO"
    BACKEND_BASE_URL: str = "http://localhost:8000"

    # Defaults
    DEFAULT_NUM_QUESTIONS_PER_QUIZ: int = 5
    MIN_CONFIDENCE_FOR_CONFIRMED_GAP: float = 0.7
    MAX_RECOMMENDATIONS_PER_GAP: int = 2

    class Config:
        env_file = ".env"
        extra = "ignore"

    @property
    def is_production(self) -> bool:
        return self.ENV.lower() in {"prod", "production"}

    @property
    def cors_origins(self) -> List[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def allowed_extensions(self) -> List[str]:
        return [e.strip().lower() for e in self.ALLOWED_FILE_EXTENSIONS.split(",") if e.strip()]

    @property
    def max_upload_bytes(self) -> int:
        return self.MAX_UPLOAD_FILE_SIZE_MB * 1024 * 1024

    def validate_runtime(self) -> None:
        """Fail fast on unsafe production configuration."""
        if not self.is_production:
            return
        if self.SECRET_KEY == DEV_SECRET_KEY:
            raise RuntimeError("SECRET_KEY must be set to a unique value in production.")
        if "*" in self.cors_origins:
            raise RuntimeError("Wildcard CORS origins are not allowed in production.")
        if self.AI_PROVIDER != "mock" and not self.AI_API_KEY:
            raise RuntimeError(f"AI_API_KEY is required for provider '{self.AI_PROVIDER}'.")


settings = Settings()
