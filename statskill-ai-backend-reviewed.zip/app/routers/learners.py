import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models import Learner, Attempt, Competency, Course
from app.schemas import LearnerResponse, LearnerDashboardResponse, DiagnosedGap, RecommendedCourse

router = APIRouter(prefix="/api/learners", tags=["Learners & Dashboard"])

@router.get("", response_model=List[LearnerResponse])
def list_learners(db: Session = Depends(get_db)):
    import datetime
    today = datetime.datetime.utcnow().date()
    yesterday = today - datetime.timedelta(days=1)

    learners = db.query(Learner).all()
    results = []
    for l in learners:
        attempts = db.query(Attempt).filter(Attempt.learner_id == l.learner_id).all()
        k_pts = sum(50 + int(a.percentage * 0.5) for a in attempts)
        unique_dates = sorted(list(set(a.completed_at.date() for a in attempts)), reverse=True)
        streak = 0
        if unique_dates:
            if unique_dates[0] == today:
                streak = 1
                curr = today - datetime.timedelta(days=1)
                for d in unique_dates[1:]:
                    if d == curr:
                        streak += 1
                        curr -= datetime.timedelta(days=1)
                    else:
                        break
            elif unique_dates[0] == yesterday:
                streak = 1
                curr = yesterday - datetime.timedelta(days=1)
                for d in unique_dates[1:]:
                    if d == curr:
                        streak += 1
                        curr -= datetime.timedelta(days=1)
                    else:
                        break
        results.append(LearnerResponse(
            learner_id=l.learner_id,
            name=l.name,
            role=l.role,
            department=l.department,
            experience_level=l.experience_level,
            preferred_language=l.preferred_language,
            karma_points=k_pts,
            streak_days=streak,
            total_quizzes=len(attempts)
        ))
    return results

@router.get("/{learner_id}", response_model=LearnerResponse)
def get_learner(learner_id: str, db: Session = Depends(get_db)):
    learner = db.query(Learner).filter(Learner.learner_id == learner_id).first()
    if not learner:
        raise HTTPException(status_code=404, detail="Learner not found")
    attempts = db.query(Attempt).filter(Attempt.learner_id == learner.learner_id).all()
    k_pts = sum(50 + int(a.percentage * 0.5) for a in attempts)
    return LearnerResponse(
        learner_id=learner.learner_id,
        name=learner.name,
        role=learner.role,
        department=learner.department,
        experience_level=learner.experience_level,
        preferred_language=learner.preferred_language,
        karma_points=k_pts,
        streak_days=0,
        total_quizzes=len(attempts)
    )

@router.get("/{learner_id}/dashboard", response_model=LearnerDashboardResponse)
def get_learner_dashboard(learner_id: str, db: Session = Depends(get_db)):
    learner = db.query(Learner).filter(Learner.learner_id == learner_id).first()
    if not learner:
        learner = db.query(Learner).first()
        if not learner:
            raise HTTPException(status_code=404, detail="No learners available")

    attempts = db.query(Attempt).filter(Attempt.learner_id == learner.learner_id).order_by(Attempt.completed_at.desc()).all()

    total_quizzes = len(attempts)
    avg_score = round(sum(a.percentage for a in attempts) / total_quizzes, 1) if total_quizzes > 0 else 0.0
    karma_points = sum(50 + int(a.percentage * 0.5) for a in attempts)

    # Accurate consecutive calendar day learning streak calculation
    import datetime
    today = datetime.datetime.utcnow().date()
    yesterday = today - datetime.timedelta(days=1)
    unique_dates = sorted(list(set(a.completed_at.date() for a in attempts)), reverse=True)
    streak_days = 0

    if unique_dates:
        if unique_dates[0] == today:
            streak_days = 1
            curr = today - datetime.timedelta(days=1)
            for d in unique_dates[1:]:
                if d == curr:
                    streak_days += 1
                    curr -= datetime.timedelta(days=1)
                else:
                    break
        elif unique_dates[0] == yesterday:
            streak_days = 1
            curr = yesterday - datetime.timedelta(days=1)
            for d in unique_dates[1:]:
                if d == curr:
                    streak_days += 1
                    curr -= datetime.timedelta(days=1)
                else:
                    break
        else:
            streak_days = 0

    # Parse recent gaps and recommendations from latest attempts
    active_gaps = []
    recommended_courses = []
    recent_attempts_data = []

    if attempts:
        latest = attempts[0]
        try:
            raw_gaps = json.loads(latest.gaps_json) if latest.gaps_json else []
            active_gaps = [DiagnosedGap(**g) for g in raw_gaps]
        except Exception:
            pass

        try:
            raw_recs = json.loads(latest.recommendations_json) if latest.recommendations_json else []
            recommended_courses = [RecommendedCourse(**r) for r in raw_recs]
        except Exception:
            pass

        for a in attempts[:5]:
            recent_attempts_data.append({
                "attempt_id": a.attempt_id,
                "quiz_id": a.quiz_id,
                "score": a.score,
                "total": a.total_questions,
                "percentage": a.percentage,
                "completed_at": a.completed_at
            })

    # Calculate Competency Mastery Radar based on real attempts or initial baseline
    all_competencies = db.query(Competency).all()
    mastery_radar = []
    base_scores = {
        "OSS-STAT-01": 80,
        "OSS-STAT-02": 65,
        "OSS-STAT-03": 50,
        "OSS-STAT-04": 75,
        "OSS-STAT-05": 70,
        "OSS-STAT-06": 85,
        "OSS-STAT-07": 90,
        "OSS-STAT-08": 60,
        "OSS-STAT-09": 65,
        "OSS-STAT-10": 80
    }
    
    for comp in all_competencies:
        val = base_scores.get(comp.competency_id, 70)
        # Adjust if recent gap exists or if high attempt score
        if any(g.competency_id == comp.competency_id for g in active_gaps):
            val = max(35, val - 25)
        elif attempts and avg_score > 70:
            val = min(100, val + 10)

        mastery_radar.append({
            "competency_id": comp.competency_id,
            "competency_name": comp.competency_name,
            "score": val,
            "domain": comp.domain
        })

    return LearnerDashboardResponse(
        learner=LearnerResponse.from_orm(learner),
        total_quizzes_taken=total_quizzes,
        average_score=avg_score,
        learning_streak_days=streak_days,
        karma_points_earned=karma_points,
        active_competency_gaps=active_gaps,
        recent_attempts=recent_attempts_data,
        recommended_courses=recommended_courses,
        competency_mastery_radar=mastery_radar
    )
