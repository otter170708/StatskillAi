# StatSkill AI — Backend

AI-enabled learning and assessment platform for India's official statistical
system (iGOT Karmayogi). Officers upload source material (circulars, manuals,
survey guidelines); the platform generates scenario-based assessments, diagnoses
competency gaps from both answers *and* answer confidence, and recommends
targeted courses.

## Architecture

```text
          upload material            generate quiz            submit answers
Client ─────────────────▶ /api/materials ─────▶ /api/quizzes ─────▶ /api/learners
                              │                     │                    │
                   document_service          ai_service          diagnostic_engine
                  (PDF / OCR / tags)     (Gemini | mock LLM)   (score + gap detection)
                              │                     │                    │
                              └───────── SQLAlchemy models ──────────────┘
                                                  │
                                      SQLite (dev) / Postgres (prod)
                                                  │
                                      recsys_service → course recommendations
                                      sme_review     → human-in-the-loop approval
```

## Run locally

```bash
pip install -r requirements.txt
cp .env.example .env      # then edit
python run.py             # http://localhost:8000/docs
```

## Configuration

All settings are environment variables (see `.env.example`). Notable ones:

| Variable | Purpose |
| --- | --- |
| `ENV` | `development` or `production`. Production enforces safe config at startup. |
| `SECRET_KEY` | Must be changed in production; startup fails otherwise. |
| `CORS_ORIGINS` | Comma-separated allow-list. Wildcards rejected in production. |
| `AI_PROVIDER` | `mock` (offline demo) or `gemini`. |
| `AI_API_KEY` | Required whenever the provider is not `mock`. |
| `MAX_UPLOAD_FILE_SIZE_MB` | Upload cap, enforced while streaming. |

## Tests

```bash
pip install pytest
pytest
```

`tests/test_diagnostic_engine.py` covers the scoring core: full-marks path,
high-confidence misconception → Critical gap, and defensive handling of unknown
question IDs and empty submissions.

## 60-second demo script

1. `GET /api/health` — service, environment and AI provider in one call.
2. `POST /api/materials/text` — paste a paragraph from an NSSO circular.
3. `POST /api/quizzes/generate` — scenario MCQs with distractor rationales.
4. `POST /api/learners/{id}/attempts` — answer with confidence levels.
5. Show the response: competency breakdown, Critical gap flagged from a
   confidently-wrong answer, and the recommended iGOT modules.

## Engineering notes

- No import-time side effects: schema creation and seeding run in the FastAPI
  lifespan handler, so tests and multi-worker deploys stay predictable.
- CPU-bound PDF/OCR parsing runs in a thread pool; AI calls are async httpx.
- A global exception handler logs stack traces and returns a generic 500.
- Structured logging throughout, level driven by `LOG_LEVEL`.
