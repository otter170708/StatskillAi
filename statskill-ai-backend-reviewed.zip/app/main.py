import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import Base, SessionLocal, engine, ensure_schema_upgrades
from app.logging_config import get_logger
from app.routers import competencies, courses, learners, materials, quizzes, sme_review
from app.services.seed_service import init_db

logger = get_logger(__name__)


def bootstrap_database() -> None:
    """Create tables, apply lightweight migrations and seed reference data."""
    Base.metadata.create_all(bind=engine)
    try:
        ensure_schema_upgrades()
    except Exception:
        logger.exception("Schema upgrade failed")
    db = SessionLocal()
    try:
        init_db(db)
    except Exception:
        logger.exception("Database seeding failed")
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # All start-up side effects live here, never at import time, so tests and
    # multi-worker deployments stay predictable.
    settings.validate_runtime()
    bootstrap_database()
    logger.info("%s started in %s mode", settings.APP_NAME, settings.ENV)
    yield
    logger.info("%s shutting down", settings.APP_NAME)


app = FastAPI(
    title=settings.APP_NAME,
    description="AI-Enabled Learning & Assessment Platform for India's Official Statistical System (iGOT Karmayogi)",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS: explicit origin list, never "*" together with credentials.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=settings.ALLOW_CREDENTIALS,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """Never leak stack traces to the client; log them server side instead."""
    logger.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. The incident has been logged."},
    )


# Register API Routers
app.include_router(materials.router)
app.include_router(quizzes.router)
app.include_router(competencies.router)
app.include_router(courses.router)
app.include_router(learners.router)
app.include_router(sme_review.router)

# Static & Frontend Handling
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
os.makedirs(STATIC_DIR, exist_ok=True)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def serve_frontend():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "StatSkill AI Backend API Running", "docs": "/docs"}


@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "app_name": settings.APP_NAME,
        "environment": settings.ENV,
        "ai_provider": settings.AI_PROVIDER,
        "ocr_enabled": settings.ENABLE_OCR,
    }
