import json
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database import get_db
from app.models import Course
from app.schemas import CourseResponse

router = APIRouter(prefix="/api/courses", tags=["iGOT Courses"])

@router.get("", response_model=List[CourseResponse])
def list_courses(
    competency_id: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    query = db.query(Course)
    courses = query.all()
    results = []
    
    for c in courses:
        try:
            comps = json.loads(c.competency_ids) if isinstance(c.competency_ids, str) else c.competency_ids
        except Exception:
            comps = []
        
        if competency_id and competency_id not in comps:
            continue

        results.append(CourseResponse(
            course_id=c.course_id,
            course_name=c.course_name,
            description=c.description,
            competency_ids=comps,
            level=c.level,
            language=c.language,
            duration_minutes=c.duration_minutes,
            provider=c.provider,
            course_url=c.course_url,
            igot_course_id=c.igot_course_id
        ))
    return results
